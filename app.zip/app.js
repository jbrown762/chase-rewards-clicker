require("dotenv").config();
const chromium = require('chrome-aws-lambda');
// const puppeteer = require('puppeteer');
const url = "https://chaseoffers.chase.com/v1/index.html?ostb=8hEVNHmGEAuvqTiC_9fVUKgiVRinq3pfBK0qNl9riIM&activate=false&mi_u=273185532&mi_ostb_2=&mi_ostb_3=&mi_id_1=b15bf866d1f2376c51de0af256682c30cd607447ad581bdac56299a6823b8549&mi_id_2=&mi_id_3=";

async function handler(event, context, callback) {
  let result = 'No result';
  let browser;

  try {
    browser = await chromium.puppeteer.launch({
      args: chromium.args,
      defaultViewport: chromium.defaultViewport,
      executablePath: await chromium.executablePath,
      headless: chromium.headless,
      ignoreHTTPSErrors: true,
    });
    const page = await browser.newPage();
    await page.goto(url);
    await page.waitForSelector(".plus-icon");
    const plusIconsClicked = await page.evaluate(() => {
      const plusIcons = [...document.getElementsByClassName("plus-icon")]
        .filter(el => el.style.display !== "none");

      plusIcons.forEach(el => el.click());
      return plusIcons.length;
    });
    result = `Offers clicked: ${plusIconsClicked}`;
    console.log("Offers clicked", plusIconsClicked)
  } catch (error) {
    return callback(error);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
  return callback(null, result);
}

// puppeteer.launch().then(async browser => {
//   const page = await browser.newPage();
//   await page.goto(url);
//   await page.waitForSelector(".plus-icon");
//   const plusIconsClicked = await page.evaluate(() => {
//     const plusIcons = [...document.getElementsByClassName("plus-icon")]
//       .filter(el => el.style.display !== "none");

//     plusIcons.forEach(el => el.click());
//     return plusIcons.length;
//   });
//   console.log("Offers clicked", plusIconsClicked)
//   browser.close();
// });

if (process.env.IS_LOCAL === "true") {
  handler();
} else {
  exports.handler = handler;
}